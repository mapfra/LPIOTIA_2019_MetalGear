--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "car-workshop";
--
-- Name: car-workshop; Type: DATABASE; Schema: -; Owner: jmbruneau
--

CREATE DATABASE "car-workshop" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE "car-workshop" OWNER TO jmbruneau;

\connect -reuse-previous=on "dbname='car-workshop'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: orders; Type: TABLE; Schema: public; Owner: jmbruneau
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    lastname character varying NOT NULL,
    firstname character varying NOT NULL,
    email character varying NOT NULL,
    brend character varying,
    model character varying,
    gearbox character varying,
    color character varying,
    options json,
    return_price numeric(9,0),
    total_price numeric(9,0),
    date time with time zone DEFAULT now()
);


ALTER TABLE public.orders OWNER TO jmbruneau;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: jmbruneau
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE;


ALTER TABLE public.orders_id_seq OWNER TO jmbruneau;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jmbruneau
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: jmbruneau
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: jmbruneau
--

COPY public.orders (id, lastname, firstname, email, brend, model, gearbox, color, options, return_price, total_price, date) FROM stdin;
\.
COPY public.orders (id, lastname, firstname, email, brend, model, gearbox, color, options, return_price, total_price, date) FROM '$$PATH$$/3182.dat';

--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jmbruneau
--

SELECT pg_catalog.setval('public.orders_id_seq', 20, true);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: jmbruneau
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

